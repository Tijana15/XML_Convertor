#include "PriorityQueue.h"
#include <iostream>


PriorityQueue::PriorityQueue()
{
	this->head = nullptr;
}

PriorityQueue::~PriorityQueue()
{
	Node* temp = this->head;
	while (temp)
	{
		this->head = temp->getNext();
		delete temp;
		temp = this->head;
	}
}

Node* PriorityQueue::addMember(std::string info)
{
	Node* newMember = new Node(info);

	//ako je red prazan
	if (this->head == nullptr)
		this->head = newMember;
	//ako je clan najveci do sad
	else if (this->head->getInfo().length() < info.length())
	{
		newMember->setNext(this->head);
		this->head = newMember;
	}
	//ako red nije prazan i clan nije najveci
	else
	{
		Node* temp = this->head;
		while (temp->getNext() != nullptr && temp->getNext()->getInfo().length() > info.length())
			temp = temp->getNext();
		newMember->setNext(temp->getNext());
		temp->setNext(newMember);
	}
	return newMember;
}

int PriorityQueue::getFirstMember(std::string* info)
{
	if (this->head == nullptr) return 0;
	Node* temp = this->head;
	*info = temp->getInfo();
	this->head = this->head->getNext();
	delete temp;
	return 1;
}

/*int PriorityQueue::deleteThisMember(int member)
{
	int br = 0;
	if (head == nullptr) return 0;
	//ako se clan nalazi na prvom mjestu, mijenjamo pokazivac na prvi
	while (this->head != nullptr && this->head->getInfo() == member)
	{
		Node* temp = this->head;
		this->head = this->head->getNext();
		delete temp;
		br++;
	}
	if (br == 0)
	{
		Node* temp = this->head;
		if (temp->getNext() == nullptr) return 0;
		while (temp->getNext()->getNext() != nullptr && temp->getNext()->getInfo() > member)
		{
			temp = temp->getNext();
		}
		while (temp->getNext() != nullptr && temp->getNext()->getInfo() == member)
		{
			br++;
			Node* temp2 = temp->getNext();
			temp->setNext(temp2->getNext());
			delete temp2;
			temp2 = nullptr;
		}
	}
	if (br)
	{
		std::cout << std::endl << "Broj elemenata koji su izbrisani: " << br << std::endl;
		return 1;
	}
	return 0;

}
*/
void PriorityQueue::printAll()
{
	Node* temp = this->head;
	std::cout << std::endl << "Ispis svih elemenata reda:" << std::endl;
	while (temp != nullptr)
	{
		std::cout << temp->getInfo() << std::endl;
		temp = temp->getNext();
	}
	std::cout << std::endl;
}