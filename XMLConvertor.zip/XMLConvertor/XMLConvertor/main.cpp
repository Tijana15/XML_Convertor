#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include "PriorityQueue.h"
#include "Stack.h"
#include "FileList.h"

using namespace std;

bool isExpressionValid(string exp);
void convertExpression(string &exp, ofstream& XMLFajl);
void convertToPrefix(string& exp);
void reverse(string& exp);



int main()
{
	string expression; //pomocni string u kojem se smijestaju izrazi iz fajla
	PriorityQueue Expressions = PriorityQueue::PriorityQueue(); //prioritetni red u kojem ce se stavljati izrazi
	FileList listOfFiles; //lista u kojoj ce se cuvati fajlovi

	ifstream Ulaz("ulaz.txt"); //pokazivac na ulazni fajl
	//Uzimamo izraz po izraz iz ulaznog fajla i ubacujemo ih na prioritetni red
	while (getline(Ulaz, expression)) {
		Expressions.addMember(expression);
	}
	Ulaz.close();
	
		
	ifstream Ulaz2("Ulaz2.txt");
	while (getline(Ulaz2, expression)) {
		Expressions.addMember(expression);
	}
	Ulaz2.close();
	
	int numOfValid = 0; //broj validnih izraza
	int numOfInvalid = 0; // broj netacnih izraza
	
	string rb;

	auto start = chrono::high_resolution_clock::now(); // kod za vrijeme izvrsavanja funkcije preuzet sa https://www.geeksforgeeks.org/measure-execution-time-function-cpp/
	cout << "Primjer rada programa: " << endl;
	while (Expressions.getFirstMember(&expression)) // sve dok ima elemenata u redu, dohvatamo izraz po izraz
	{
		//provjeravamo da li je izraz validan, ako jeste vrsimo konverziju
		if (isExpressionValid(expression))
		{
			numOfValid++;
			rb = to_string(numOfValid);
			ofstream XMLfajl("izraz_" + rb + ".xml");
			
			convertExpression(expression, XMLfajl);
			//Dodaj u listu XMLFajl
			listOfFiles.addMember("izraz_" + rb + ".xml");
			XMLfajl.close();
		}
		else
			numOfInvalid++;
	}
	auto stop = chrono::high_resolution_clock::now();

	cout << "Broj uspjesnih konverzija: " << numOfValid << endl;
	cout << "Broj neuspjesnih konverzija: " << numOfInvalid << endl;

	auto duration = chrono::duration_cast<chrono::microseconds>(stop - start); // vrijeme trajanja funkcije
	cout << "Trajanje konverzije: " << duration.count() << "us" << endl;

	listOfFiles.printAll();

	string input;
	cout << "Ukoliko zelite da otvorite fajl napisite njegovo ime, inace napisite KRAJ:" << endl;
	cin >> input;
	while (input != "KRAJ")
	{
		//izvrsava dodatne provjere kako ne bismo bespotrebno vrsili pretragu reda
		if(input.length() > 10 && input.substr(0, 6) == "izraz_" && input.substr(input.length()-4, 4) == ".xml")
		{
			if (!listOfFiles.findAndWrite(input))
				cout << "Pogresan naziv fajla. Pokusajte ponovo" << endl;
		}
		else 
			cout << "Pogresan naziv fajla. Pokusajte ponovo" << endl;
		cout << "Ukoliko zelite da otvorite fajl napisite njegovo ime, inace napisite KRAJ:" << endl;
		cin >> input;
	}
	

	return 0;
}

bool isExpressionValid(string exp)
{
	int i, leftParentheses = 0, rightParentheses = 0, rank = 0 , shouldParentheses = -1;
	for (i = 0; i < exp.length(); i++)
	{
		if (exp[i] == '(')
			leftParentheses++;
		else if (exp[i] >= 'A' && exp[i] <= 'Z')
			rank++;
		else if (exp[i] == '&' || exp[i] == '|')
		{ 
			rank--;
			shouldParentheses++;
		}
			
		else if (exp[i] == '!') 
			shouldParentheses++;
		else if (exp[i] == ')')
			rightParentheses++;
		else return false; 

	}
	if ((rank == 1) && (leftParentheses == rightParentheses) && (leftParentheses == shouldParentheses)) return true;
	return false;
}

void convertExpression(string& exp, ofstream& XMLFajl)
{
	convertToPrefix(exp);
	Stack XML;
	XMLFajl << "<expression>\n";
	for (int i = 0; i < exp.length(); i++)
	{
		if (exp[i] == '!')
		{
			XMLFajl << "<not>\n";
			XML.push('!');
		}
		else if (exp[i] == '&')
		{
			XMLFajl << "<and>\n";
			XML.push('&');
		}
		else if (exp[i] == '|')
		{
			XMLFajl << "<or>\n";
			XML.push('|');
		}
		else if (exp[i] >= 'A' && exp[i] <= 'Z')
		{
			XMLFajl << "<operand>" << exp[i] << "</operand>\n";
		}
		else if (exp[i] == '(') continue;
		else
		{
			char temp;
			XML.pop(&temp);
			if (temp == '!')
			{
				XMLFajl << "</not>\n";	
			}
			else if (temp == '&')
			{
				XMLFajl << "</and>\n";				
			}
			else if (temp == '|')
			{
				XMLFajl << "</or>\n";	
			}
		}

	}
	if (!XML.isEmpty())
	{
		char temp;
		XML.pop(&temp);
		if (temp == '!')
		{
			XMLFajl << "</not>\n";
		}
		else if (temp == '&')
		{
			XMLFajl << "</and>\n";
		}
		else if (temp == '|')
		{
			XMLFajl << "</or>\n";
		}
	}
	XMLFajl << "</expression>";

}

void convertToPrefix(string& exp)
{
	char x;
	Stack Prefix;
	string temp;
	for (int i = 0; i < exp.length(); i++)
	{
		if (exp[i] >= 'A' && exp[i] <= 'Z')
		{
			temp+=exp[i];
		}
		else if (exp[i] == '(')
		{
			temp += exp[i];
			Prefix.push(exp[i]);
		}
		else
		{
			while ((!Prefix.isEmpty()) && (Prefix.getTosElement() != '('))
			{
				Prefix.pop(&x);
				temp += x;
			}
			if (Prefix.isEmpty() || exp[i] != ')')
				Prefix.push(exp[i]);
			else if (exp[i] == ')')
			{
				Prefix.pop(&x);
				temp += exp[i];
			}
			else
				Prefix.pop(&x);
		}
		
	}
	while (!Prefix.isEmpty())
	{
		Prefix.pop(&x);
		temp += x;
	}
	reverse(temp);
	exp = temp;
}

void reverse(string& exp)
{
	char temp;
	for (int i = 0; i < exp.length() / 2; i++)
	{
		if (exp[i] == '(')
			exp[i] = ')';
		else if (exp[i] == ')')
			exp[i] = '(';
		if (exp[exp.length() - i - 1] == '(')
			exp[exp.length() - i - 1] = ')';
		else if (exp[exp.length() - i - 1] == ')')
			exp[exp.length() - i - 1] = '(';
		temp = exp[i];
		exp[i] = exp[exp.length() - i - 1];
		exp[exp.length() - i - 1] = temp;
	}
	if (exp.length() % 2 == 1)
	{
		if (exp[exp.length() / 2] == '(')
			exp[exp.length() / 2] = ')';
		else if (exp[exp.length() / 2] == ')')
			exp[exp.length() / 2] = '(';

	}
}
