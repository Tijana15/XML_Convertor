#include "Stack.h"

bool Stack::isEmpty()
{
	if (tos == nullptr) return true;
	return false;
}

Stack::Stack() : tos(nullptr)
{
}

Stack::~Stack()
{
	StackNode* temp = this->tos;
	while (temp)
	{
		this->tos = temp->getNext();
		delete temp;
		temp = this->tos;
	}
}

char Stack::getTosElement()
{
	return tos->getInfo();
	return 0;
}

void Stack::push(char info)
{
	StackNode* newMember = new StackNode(info);
	if (this->isEmpty()) this->tos = newMember;
	else
	{
		newMember->setNext(tos);
		tos = newMember;
	}
}

bool Stack::pop(char* info)
{
	if(this->isEmpty()) return false;
	*info = tos->getInfo();
	StackNode* temp = tos;
	tos = tos->getNext();
	delete temp;
}
