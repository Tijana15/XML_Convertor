#pragma once

class StackNode
{
private:
	char info;
	StackNode* next;
public:
	StackNode();
	StackNode(char info);
	void setInfo(char information);
	char getInfo() const;
	void setNext(StackNode* nextNode);
	StackNode* getNext() const;

};
