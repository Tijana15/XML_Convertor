#pragma once

#include "StackNode.h"

class Stack
{
private:
	StackNode* tos;	
public:
	Stack();
	~Stack();
	char getTosElement();
	bool isEmpty();
	void push(char info);
	bool pop(char* info);
};
