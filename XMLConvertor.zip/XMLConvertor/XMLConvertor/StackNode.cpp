#include "StackNode.h"


StackNode::StackNode() : info('0'), next(nullptr)
{
}

StackNode::StackNode(char info) : info(info), next(nullptr)
{
}
void StackNode::setInfo(char information)
{
	this->info = information;
}
char StackNode::getInfo() const
{
	return this->info;
}
void StackNode::setNext(StackNode* nextNode)
{
	this->next = nextNode;
}
StackNode* StackNode::getNext() const
{
	return this->next;
}