#pragma once
#include "Node.h"
#include <iostream>
#include <fstream>

class FileList
{
private:
	Node* head;
public:
	FileList();
	~FileList();
	Node* addMember(std::string info);
	void printAll();
	bool findAndWrite(std::string file);
};
