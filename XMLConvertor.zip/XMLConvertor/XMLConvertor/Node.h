#pragma once
#include <string>

class Node
{
private:
	std::string info;
	Node* next;
public:
	Node();
	Node(std::string info);
	void setInfo(std::string information);
	std::string getInfo() const;
	void setNext(Node* nextNode);
	Node* getNext() const;

};