#include "FileList.h"

FileList::FileList() : head(nullptr)
{
}

FileList::~FileList()
{
	Node* temp = this->head;
	while (temp)
	{
		this->head = temp->getNext();
		delete temp;
		temp = this->head;
	}
}

Node* FileList::addMember(std::string info)
{
	Node* newMember = new Node(info);

	//ako je red prazan
	if (this->head == nullptr)
		this->head = newMember;
	//ako red nije prazan
	else
	{
		Node* temp = this->head;
		while (temp->getNext() != nullptr)
			temp = temp->getNext();
		//newMember->setNext(nullptr);
		temp->setNext(newMember);
	}
	return newMember;
}

void FileList::printAll()
{
	Node* temp = this->head;
	std::cout << std::endl << "Spisak dostupnih fajlova:" << std::endl;
	while (temp != nullptr)
	{
		std::cout << temp->getInfo() << std::endl;
		temp = temp->getNext();
	}
	std::cout << std::endl;
}

bool FileList::findAndWrite(std::string file)
{
	Node* temp = head;
	std::string tekst;
	std::ifstream XMLFajl(file);
	while (temp != nullptr)
	{
		if (temp->getInfo() == file)
		{
			
			while (std::getline(XMLFajl, tekst))
			{
				std::cout << tekst << std::endl;
			}
			return true;
		}
		temp = temp->getNext();
	}
	return false;
}
