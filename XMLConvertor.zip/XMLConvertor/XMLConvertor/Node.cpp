#include "Node.h"


Node::Node() : info(""), next(nullptr)
{
}

Node::Node(std::string info) : info(info), next(nullptr)
{
}
void Node::setInfo(std::string information)
{
	this->info = information;
}
std::string Node::getInfo() const
{
	return this->info;
}
void Node::setNext(Node* nextNode)
{
	this->next = nextNode;
}
Node* Node::getNext() const
{
	return this->next;
}