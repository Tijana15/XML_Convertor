#pragma once
#include "Node.h"


//dinamicki alociran prosiriv prioritetni red podataka tipa int
//najmanji podaci idu na kraj reda
class PriorityQueue
{
private:
	Node* head;
public:
	//omoguciti inicijalizaciju praznog reda upotrebom podrazumijevanog konstruktora
	PriorityQueue();
	//destruktor, brise sve clanove
	~PriorityQueue();
	//dodavanje elemenata u red
	Node* addMember(std::string info);
	//uklanjanje elemenata sa najvisim prioritetom iz reda
	int getFirstMember(std::string* info);
	//uklanjanje odredjenog elementa iz reda
	//int deleteThisMember(int member);
	//ispis svih elemenata reda
	void printAll();
};
